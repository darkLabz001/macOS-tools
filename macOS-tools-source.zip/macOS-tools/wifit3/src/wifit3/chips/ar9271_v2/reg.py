"""AR9271 MAC/RTC/PHY register addresses + bit values, ported from reg.h / phy.h / hw.h.

Addresses are resolved for the AR9271 (the only silicon this driver claims). Where the kernel
macro is chip-conditional, the comment records the resolved branch so the value is traceable
to the source. Citations: ``driver_sources/ath9k-source-v6.18.12/<file>:line`` at v6.18.12.
"""
from __future__ import annotations


def _shift(mask: int) -> int:
    return (mask & -mask).bit_length() - 1


def SM(value: int, mask: int) -> int:
    """Set-field: place ``value`` into the bits ``mask`` covers (ath9k SM macro)."""
    return (value << _shift(mask)) & mask


def MS(value: int, mask: int) -> int:
    """Get-field: extract the bits ``mask`` covers from ``value`` (ath9k MS macro)."""
    return (value & mask) >> _shift(mask)

# ---- SREV (silicon revision) [SRC] reg.h:753-795 ---------------------------
AR_SREV = 0x4020                       # AR_SREV(ah) for non-9100/9340
AR_SREV_ID = 0x000000FF                # non-9100 mask
AR_SREV_VERSION = 0x000000F0
AR_SREV_VERSION_S = 4
AR_SREV_REVISION = 0x00000007
AR_SREV_VERSION2 = 0xFFFC0000
AR_SREV_TYPE2_S = 12
AR_SREV_TYPE2_HOST_MODE = 0x00002000
AR_SREV_REVISION2 = 0x00000F00
AR_SREV_REVISION2_S = 8
AR_SREV_VERSION_9271 = 0x140           # [SRC] reg.h:795
AR_SREV_VERSION_9285 = 0xC0            # [SRC] reg.h:786 (AR_SREV_9285_12_OR_LATER threshold)

# ---- reset / RTC [SRC] reg.h:697-702,1041-1063,1342-1406 -------------------
AR_WA = 0x4004                         # AR_WA(ah) non-9340 [SRC] reg.h:702 (9300+ only)
AR_WA_D3_L1_DISABLE = 0x00004000
AR_WA_ASPM_TIMER_BASED_DISABLE = 0x00020000

AR_RC = 0x4000                         # MAC DMA reset control
AR_RC_AHB = 0x00000001
AR_RC_HOSTIF = 0x00000100

AR_INTR_SYNC_CAUSE = 0x4028            # non-9340
AR_INTR_SYNC_ENABLE = 0x402c           # non-9340
AR_INTR_SYNC_RADM_CPL_TIMEOUT = 0x00001000
AR_INTR_SYNC_LOCAL_TIMEOUT = 0x00002000

AR_RTC_RC = 0x7000                     # non-9100
AR_RTC_RC_M = 0x00000003
AR_RTC_RC_MAC_WARM = 0x00000001
AR_RTC_RC_MAC_COLD = 0x00000002

AR_RTC_RESET = 0x7040                  # non-9100
AR_RTC_RESET_EN = 0x00000001

AR_RTC_STATUS = 0x7044                 # non-9100
AR_RTC_STATUS_M = 0x0000000f           # non-9100
AR_RTC_STATUS_ON = 0x00000002
AR_RTC_STATUS_SHUTDOWN = 0x00000001    # [SRC] reg.h:1393

AR_RTC_FORCE_WAKE = 0x704c             # non-9100
AR_RTC_FORCE_WAKE_EN = 0x00000001
AR_RTC_FORCE_WAKE_ON_INT = 0x00000002

# ---- station id / power save -----------------------------------------------
AR_STA_ID0 = 0x8000                    # [SRC] ath/reg.h:26 (shared ath common)
AR_STA_ID1 = 0x8004
AR_STA_ID1_PWR_SAV = 0x00040000        # [SRC] reg.h:1621
AR_STA_ID1_BASE_RATE_11B = 0x02000000  # [SRC] reg.h:1629

# ---- reset preamble (ath9k_hw_reset) [SRC] reg.h:395-1721 ------------------
AR_CR = 0x0008
AR_CR_RXE = 0x00000004                 # non-9300
AR_Q_TXE = 0x0840
AR_NUM_QCU = 10                        # [SRC] reg.h:368
AR_Q0_STS = 0x0a00                     # [SRC] reg.h:468
AR_Q_STS_PEND_FR_CNT = 0x00000003      # [SRC] reg.h:479
def AR_QSTS(i: int) -> int: return AR_Q0_STS + (i << 2)   # AR_QSTS(_i) [SRC] reg.h:478
AR_TSF_L32 = 0x804c
AR_TSF_U32 = 0x8050
AR_DEF_ANTENNA = 0x8058
AR_CFG_LED = 0x1f04
AR_CFG_LED_SAVE_MASK = 0x00000c00 | 0x00000380 | 0x00000070 | 0x00000008  # ASSOC|MODE|THRESH|SLOW
AR_PHY_ACTIVE = 0x981c                 # [SRC] ar9002_phy.h:50
AR_PHY_ACTIVE_DIS = 0x00000000
AR_PHY_ACTIVE_EN = 0x00000001
AR_PHY_RX_DELAY = 0x9914               # [SRC] ar9002_phy.h:186
AR_PHY_RX_DELAY_DELAY = 0x00003FFF
AR_GPIO_INPUT_EN_VAL = 0x4054          # non-9340/non-9300
AR_GPIO_JTAG_DISABLE = 0x00020000
AR9271_RESET_POWER_DOWN_CONTROL = 0x50044   # [SRC] reg.h:1615
AR9271_RADIO_RF_RST = 0x20
AR9271_GATE_MAC_CTL = 0x4000

# ---- EEPROM access (USB) [SRC] eeprom.h:66-68,177 / reg.h:1250-1256 --------
AR5416_EEPROM_OFFSET = 0x2000          # EEPROM word window base
AR5416_EEPROM_S = 2                    # word -> byte-address shift (<<2)
AR_EEPROM_STATUS_DATA = 0x407c         # non-9340
AR_EEPROM_STATUS_DATA_VAL = 0x0000ffff
AR_EEPROM_STATUS_DATA_BUSY = 0x00010000
AR_EEPROM_STATUS_DATA_PROT_ACCESS = 0x00040000

SIZE_EEPROM_4K = 188                   # sizeof(ar5416_eeprom_4k)/2 [SRC] eeprom_4k.c:36
AR5416_EEP4K_START_LOC = 64            # [SRC] eeprom_4k.c:56
AR5416_EEPROM_MAGIC = 0xa55a           # [SRC] eeprom.h:36-41 (#else = little-endian host)
AR5416_EEPROM_MAGIC_OFFSET = 0x0       # [SRC] eeprom.h:66
AR5416_EEPMISC_BIG_ENDIAN = 0x01       # [SRC] eeprom.h:177
AR5416_EEP_VER = 0xE                   # [SRC] eeprom.h:133
AR5416_EEP_NO_BACK_VER = 0x1           # [SRC] eeprom.h:132
AR5416_EEP_VER_MAJOR_SHIFT = 12        # [SRC] eeprom.h:134-136
AR5416_EEP_VER_MAJOR_MASK = 0xF000
AR5416_EEP_VER_MINOR_MASK = 0x0FFF

# ---- radio revision (ar9002) [SRC] reg.h:1014-1018 -------------------------
AR_RADIO_SREV_MAJOR = 0xf0
AR_RAD5133_SREV_MAJOR = 0xc0
AR_RAD2133_SREV_MAJOR = 0xd0
AR_RAD5122_SREV_MAJOR = 0xe0
AR_RAD2122_SREV_MAJOR = 0xf0

# ---- ANI / MIB counters [SRC] reg.h:1767-1862 + ath/reg.h:20-24 ------------
AR_MIBC = 0x0040                       # [SRC] ath/reg.h:20 (shared ath common)
AR_MIBC_COW = 0x00000001
AR_MIBC_FMC = 0x00000002
AR_MIBC_CMC = 0x00000004
AR_MIBC_MCS = 0x00000008

AR_RTS_OK = 0x8088
AR_RTS_FAIL = 0x808c
AR_ACK_FAIL = 0x8090
AR_FCS_FAIL = 0x8094
AR_BEACON_CNT = 0x8098

AR_FILT_OFDM = 0x8124
AR_FILT_CCK = 0x8128
AR_PHY_ERR_1 = 0x812c
AR_PHY_ERR_MASK_1 = 0x8130
AR_PHY_ERR_2 = 0x8134
AR_PHY_ERR_MASK_2 = 0x8138
AR_PHY_ERR_OFDM_TIMING = 0x00020000    # [SRC] reg.h:1820
AR_PHY_ERR_CCK_TIMING = 0x02000000     # [SRC] reg.h:1821

# ---- GPIO / LED [SRC] reg.h:1159-1244 + hw.h:144 + htc.h:397 ---------------
AR_GPIO_IN_OUT = 0x4048                # non-9340
AR_GPIO_OE_OUT = 0x404c                # non-9340/non-9300
AR_GPIO_OE_OUT_DRV_NO = 0x0
AR_GPIO_OE_OUT_DRV_ALL = 0x3
AR_GPIO_OE_OUT_DRV = 0x3
AR_GPIO_OUTPUT_MUX3 = 0x4068           # non-9340/non-9300 (gpio > 11, e.g. the led pin)
AR_GPIO_OUTPUT_MUX_AS_OUTPUT = 0       # [SRC] hw.h:144
ATH_LED_PIN_9271 = 15                  # [SRC] htc.h:397

# ---- key cache [SRC] ath/reg.h:42-62 + hw.h:180 ----------------------------
AR_KEYTABLE_0 = 0x8800
AR_KEYTABLE_SIZE = 128
AR_KEYTABLE_TYPE_CLR = 0x00000007
AR_KEYTABLE_TYPE_TKIP = 0x00000004
def AR_KEYTABLE(n: int) -> int:        # AR_KEYTABLE(_n) = AR_KEYTABLE_0 + (_n * 32)
    return AR_KEYTABLE_0 + (n * 32)

# ---- PHY [SRC] phy.h:24-25,43 ----------------------------------------------
AR_PHY_BASE = 0x9800
def AR_PHY(n: int) -> int:             # AR_PHY(_n) = AR_PHY_BASE + (_n << 2)
    return AR_PHY_BASE + (n << 2)
AR_PHY_CHIP_ID = 0x9818                # [SRC] phy.h:43
AR_PHY_ADC_SERIAL_CTL = 0x9830         # [SRC] ar9002_phy.h:75
AR_PHY_SEL_INTERNAL_ADDAC = 0x00000000
AR_PHY_SEL_EXTERNAL_RADIO = 0x00000001
AR_AN_TOP2 = 0x7894                     # [SRC] reg.h:1457
AR_AN_TOP2_PWDCLKIND = 0x00400000
AR5416_EEP_TXGAIN_HIGH_POWER = 1        # [SRC] eeprom.h:174 (0 = original/normal)

# ---- process_ini override + per-channel regs [SRC] ar5008_phy.c:653-734 ----
AR_DIAG_SW = 0x8048                     # [SRC] reg.h:1689
AR_DIAG_RX_DIS = 0x00000020
AR_DIAG_RX_ABORT = 0x02000000

# ---- RX control / filter (host_rx_init) [SRC] reg.h:1675 + mac.h:642 ----
AR_RX_FILTER = 0x803C                   # [SRC] reg.h:1675
AR_PHY_ERR = 0x810C                     # [SRC] reg.h:1816 (filter phy-err, not the ANI counters)
AR_PHY_ERR_RADAR = 0x00000020           # [SRC] reg.h:1819
AR_MCAST_FIL0 = 0x8040                  # [SRC] reg.h:1677
AR_MCAST_FIL1 = 0x8044
AR_RXCFG_ZLFDMA = 0x00000010            # [SRC] reg.h:101
ATH9K_RX_FILTER_UCAST = 0x00000001      # [SRC] mac.h:643
ATH9K_RX_FILTER_MCAST = 0x00000002
ATH9K_RX_FILTER_BCAST = 0x00000004
ATH9K_RX_FILTER_CONTROL = 0x00000008
ATH9K_RX_FILTER_BEACON = 0x00000010
ATH9K_RX_FILTER_PROM = 0x00000020
ATH9K_RX_FILTER_PROBEREQ = 0x00000080
ATH9K_RX_FILTER_PHYERR = 0x00000100
ATH9K_RX_FILTER_MYBEACON = 0x00000200
ATH9K_RX_FILTER_COMP_BAR = 0x00000400
ATH9K_RX_FILTER_UNCOMP_BA_BAR = 0x00001000
ATH9K_RX_FILTER_PHYRADAR = 0x00002000
ATH9K_RX_FILTER_PSPOLL = 0x00004000
ATH9K_RX_FILTER_MCAST_BCAST_ALL = 0x00008000
AR_PCU_MISC_MODE2 = 0x8344             # [SRC] reg.h:2041
AR_PCU_MISC_MODE2_CFP_IGNORE = 0x00000080
AR_PCU_MISC_MODE2_HWWAR1 = 0x00100000
AR_ADHOC_MCAST_KEYID_ENABLE = 0x00000040
AR_PHY_TURBO = 0x9804                   # [SRC] ar9002_phy.h:23
AR_PHY_FC_HT_EN = 0x00000040
AR_PHY_FC_SHORT_GI_40 = 0x00000080
AR_PHY_FC_WALSH = 0x00000100
AR_PHY_FC_SINGLE_HT_LTF1 = 0x00000200
AR_PHY_FC_ENABLE_DAC_FIFO = 0x00000800
AR_2040_MODE = 0x8318                   # [SRC] reg.h:2027
AR_2040_JOINED_RX_CLEAR = 0x00000001
AR_GTXTO = 0x0064                       # [SRC] reg.h:160
AR_GTXTO_TIMEOUT_LIMIT_S = 16
AR_CST = 0x006c                         # [SRC] reg.h:171
AR_CST_TIMEOUT_LIMIT_S = 16

# ---- chain masks [SRC] ar9002_phy.h:304-563 + reg.h:2033 -------------------
AR_PHY_RX_CHAINMASK = 0x99a4
AR_PHY_CAL_CHAINMASK = 0xa39c
AR_SELFGEN_MASK = 0x832c
AR_PHY_ANALOG_SWAP = 0xa268
AR_PHY_SWAP_ALT_CHAIN = 0x00000040

# ---- PLL / clock [SRC] reg.h:1334-1400 -------------------------------------
AR_RTC_PLL_CONTROL = 0x7014            # non-9100/soc
AR_RTC_9160_PLL_DIV = 0x000003ff
AR_RTC_9160_PLL_REFDIV = 0x00003c00
AR_RTC_9160_PLL_CLKSEL = 0x0000c000
AR_RTC_SLEEP_CLK = 0x7048              # non-9100
AR_RTC_FORCE_DERIVED_CLK = 0x2
AR9271_CORE_CLOCK = 0x50040            # [SRC] hw.c:924 "switch core clock to 117MHz"
AR9271_CORE_CLOCK_VAL = 0x304

# ---- timing [SRC] hw.h:177-181 ---------------------------------------------
AH_WAIT_TIMEOUT = 100000               # us
AH_TIME_QUANTUM = 10                   # us
POWER_UP_TIME = 10000                  # us

# ---- reset types [SRC] hw.h enum ath9k_reset_type --------------------------
ATH9K_RESET_POWER_ON = 1
ATH9K_RESET_WARM = 2
ATH9K_RESET_COLD = 3

# ---- TX power [SRC] ar9002_phy.h:209-561 + eeprom.h:108-175 ----------------
MAX_RATE_POWER = 63                     # [SRC] hw.h:175
AR5416_PWR_TABLE_OFFSET_DB = -5         # [SRC] eeprom.h:165
def ATH9K_POW_SM(r: int, s: int) -> int:    # [SRC] eeprom.h:108
    return (r & 0x3f) << s
# per-rate registers (op397)
AR_PHY_POWER_TX_RATE1 = 0x9934          # [SRC] ar9002_phy.h:209
AR_PHY_POWER_TX_RATE2 = 0x9938
AR_PHY_POWER_TX_RATE3 = 0xA234          # [SRC] ar9002_phy.h:456
AR_PHY_POWER_TX_RATE4 = 0xA238
AR_PHY_POWER_TX_RATE5 = 0xA38C          # [SRC] ar9002_phy.h:560
AR_PHY_POWER_TX_RATE6 = 0xA390
AR_PHY_POWER_TX_RATE_MAX = 0x993C       # [SRC] ar9002_phy.h:211
# PDADC gain config (op395 RMW / op396 write) [SRC] ar9002_phy.h:464-553
AR_PHY_TPCRG1 = 0xA258
AR_PHY_TPCRG1_NUM_PD_GAIN = 0x0000c000
AR_PHY_TPCRG1_PD_GAIN_1 = 0x00030000
AR_PHY_TPCRG1_PD_GAIN_2 = 0x000C0000
AR_PHY_TPCRG1_PD_GAIN_3 = 0x00300000
AR_PHY_TPCRG5 = 0xA26C
AR_PHY_TPCRG5_PD_GAIN_OVERLAP = 0x0000000F
AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_1 = 0x000003F0
AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_2 = 0x0000FC00
AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_3 = 0x003F0000
AR_PHY_TPCRG5_PD_GAIN_BOUNDARY_4 = 0x0FC00000

# ---- EEPROM 4k map [SRC] eeprom.h:155-187 ----------------------------------
AR5416_BCHAN_UNUSED = 0xFF
AR5416_NUM_PD_GAINS = 4
AR5416_PD_GAINS_IN_MASK = 4
AR5416_PD_GAIN_ICEPTS = 5
AR5416_NUM_PDADC_VALUES = 128
AR5416_MAX_PWR_RANGE_IN_HALF_DB = 64
AR5416_EEP4K_NUM_PD_GAINS = 2
AR5416_EEP4K_MAX_CHAINS = 1
AR5416_EEP4K_NUM_2G_CAL_PIERS = 3
AR5416_EEP4K_NUM_BAND_EDGES = 4
AR5416_EEP4K_NUM_CTLS = 12
AR5416_EEP_MINOR_VER_2 = 0x2
AR5416_EEP_MINOR_VER_3 = 0x3
# CTL group selectors [SRC] eeprom.h:74-94
SD_NO_CTL = 0xE0
CTL_MODE_M = 0xf
CTL_11B = 1
CTL_11G = 2
CTL_2GHT20 = 5
CTL_2GHT40 = 7
CTL_5GHT40 = 8
EXT_ADDITIVE = 0x8000
CTL_11G_EXT = CTL_11G | EXT_ADDITIVE
CTL_11B_EXT = CTL_11B | EXT_ADDITIVE
SUB_NUM_CTL_MODES_AT_2G_40 = 3
def CTL_EDGE_TPOWER(ctl: int) -> int:       # [SRC] eeprom.h:217
    return ctl & 0x3f
def CTL_EDGE_FLAGS(ctl: int) -> int:        # [SRC] eeprom.h:218
    return (ctl >> 6) & 0x03

# ---- reset tail: rfmode / mfp / delta-slope / spur [SRC] ar5008_phy.c + hw.c -
AR_PHY_MODE = 0xA200                    # [SRC] ar9002_phy.h:401
AR_PHY_MODE_DYNAMIC = 0x04
AR_PHY_MODE_OFDM = 0x00
AR_PHY_MODE_RF2GHZ = 0x02
AR_AES_MUTE_MASK1 = 0x8060              # [SRC] reg.h:2072
AR_AES_MUTE_MASK1_FC_MGMT = 0xFFFF0000
AR_AES_MUTE_MASK1_FC_MGMT_VAL = 0xc7ff  # [SRC] hw.c init_mfp
COEF_SCALE_S = 24                       # [SRC] hw.h:166
AR_PHY_TIMING3 = 0x9814                 # [SRC] ar9002_phy.h:40
AR_PHY_TIMING3_DSC_MAN = 0xFFFE0000
AR_PHY_TIMING3_DSC_EXP = 0x0001E000
AR_PHY_HALFGI = 0x99D0                  # [SRC] ar9002_phy.h:360
AR_PHY_HALFGI_DSC_MAN = 0x0007FFF0
AR_PHY_HALFGI_DSC_EXP = 0x0000000F
AR_PHY_FORCE_CLKEN_CCK = 0xA22C         # [SRC] ar9002_phy.h:453
AR_PHY_FORCE_CLKEN_CCK_MRC_MUX = 0x00000040
AR_NO_SPUR = 0x8000                     # [SRC] hw.h:313
AR_BASE_FREQ_2GHZ = 2300                # [SRC] hw.h:314
AR_SPUR_FEEQ_BOUND_HT20 = 10            # [SRC] hw.h:317

# ---- eeprom set_board_values / set_gain [SRC] eeprom_4k.c + ar9002_phy.h/reg.h ----
AR_PHY_SWITCH_COM = 0x9964              # [SRC] ar9002_phy.h:255
AR_PHY_SWITCH_CHAIN_0 = 0x9960          # [SRC] ar9002_phy.h:254
AR_PHY_TIMING_CTRL4_0 = 0x9920          # AR_PHY_TIMING_CTRL4(0) [SRC] ar9002_phy.h:190
AR_PHY_TIMING_CTRL4_IQCORR_Q_Q_COFF = 0x01F
AR_PHY_TIMING_CTRL4_IQCORR_Q_I_COFF = 0x7E0
AR_PHY_GAIN_2GHZ = 0xA20C               # [SRC] ar9002_phy.h:427
AR_PHY_GAIN_2GHZ_XATTEN1_MARGIN = 0x0001F000
AR_PHY_GAIN_2GHZ_XATTEN1_DB = 0x0000003F
AR_PHY_GAIN_2GHZ_XATTEN2_MARGIN = 0x003E0000
AR_PHY_GAIN_2GHZ_XATTEN2_DB = 0x00000FC0
AR_PHY_RXGAIN = 0x9848                  # [SRC] ar9002_phy.h:95
AR9280_PHY_RXGAIN_TXRX_ATTEN = 0x00003F80
AR9280_PHY_RXGAIN_TXRX_MARGIN = 0x001FC000
AR_PHY_MULTICHAIN_GAIN_CTL = 0x99AC     # [SRC] ar9002_phy.h:309
AR_PHY_9285_ANT_DIV_CTL_ALL = 0x7F000000
AR_PHY_9285_ANT_DIV_CTL = 0x01000000
AR_PHY_9285_ANT_DIV_ALT_LNACONF = 0x06000000
AR_PHY_9285_ANT_DIV_MAIN_LNACONF = 0x18000000
AR_PHY_9285_ANT_DIV_ALT_GAINTB = 0x20000000
AR_PHY_9285_ANT_DIV_MAIN_GAINTB = 0x40000000
AR_PHY_CCK_DETECT = 0xA208              # [SRC] ar9002_phy.h:418
AR_PHY_CCK_DETECT_BB_ENABLE_ANT_FAST_DIV = 0x2000
AR9285_AN_RF2G3 = 0x7828                # [SRC] reg.h:1484
AR9285_AN_RF2G4 = 0x782C                # [SRC] reg.h:1504
AR9271_AN_RF2G3_OB_cck = 0x001C0000     # [SRC] reg.h:1529
AR9271_AN_RF2G3_OB_psk = 0x00038000
AR9271_AN_RF2G3_OB_qam = 0x00007000
AR9271_AN_RF2G3_DB_1 = 0x00E00000
AR9271_AN_RF2G4_DB_2 = 0xE0000000
AR_PHY_SETTLING = 0x9844                # [SRC] ar9002_phy.h:91
AR_PHY_SETTLING_SWITCH = 0x00003F80
AR_PHY_DESIRED_SZ = 0x9850              # [SRC] ar9002_phy.h:105
AR_PHY_DESIRED_SZ_ADC = 0x000000FF
AR_PHY_RF_CTL4 = 0x9834                 # [SRC] ar9002_phy.h:79
AR_PHY_RF_CTL4_TX_END_XPAB_OFF = 0xFF000000
AR_PHY_RF_CTL4_TX_END_XPAA_OFF = 0x00FF0000
AR_PHY_RF_CTL4_FRAME_XPAB_ON = 0x0000FF00
AR_PHY_RF_CTL4_FRAME_XPAA_ON = 0x000000FF
AR_PHY_RF_CTL3 = 0x9828                 # [SRC] ar9002_phy.h:60
AR_PHY_TX_END_TO_A2_RX_ON = 0x00FF0000
AR_PHY_CCA = 0x9864                     # [SRC] ar9002_phy.h:129
AR9280_PHY_CCA_THRESH62 = 0x000FF000
AR_PHY_EXT_CCA0 = 0x99B8                # [SRC] ar9002_phy.h:332
AR_PHY_EXT_CCA0_THRESH62 = 0x000000FF
AR_PHY_RF_CTL2 = 0x9824                 # [SRC] ar9002_phy.h:54
AR_PHY_TX_END_DATA_START = 0x000000FF
AR_PHY_TX_END_PA_ON = 0x0000FF00
EEP_4K_BB_DESIRED_SCALE_MASK = 0x1f     # [SRC] eeprom.h
# bb_desired_scale (smart-antenna) TX-pwrctrl regs — set_board_values txGainType==0 branch.
AR_PHY_TX_PWRCTRL8 = 0xa278             # [SRC] ar9002_phy.h:493
AR_PHY_TX_PWRCTRL9 = 0xa27C             # [SRC] ar9002_phy.h:495
AR_PHY_TX_PWRCTRL10 = 0xa394            # [SRC] ar9002_phy.h:497
AR_PHY_CH0_TX_PWRCTRL11 = 0xa398        # [SRC] ar9002_phy.h:507
AR_PHY_CH0_TX_PWRCTRL12 = 0xa3dc        # [SRC] ar9002_phy.h:509
AR_PHY_CH0_TX_PWRCTRL13 = 0xa3e0        # [SRC] ar9002_phy.h:510
CHAIN_BLOCK1_OFFSET = 0x1000            # block-1 = block-0 + 0x1000

# ---- calibration (ar9002_hw_init_cal): cl_cal / pa_cal / NF / IQ setup ----
AR_PHY_AGC_CONTROL = 0x9860             # AR9002_PHY_AGC_CONTROL [SRC] reg.h:2115
AR_PHY_AGC_CONTROL_CAL = 0x00000001     # [SRC] reg.h:2118
AR_PHY_AGC_CONTROL_NF = 0x00000002      # [SRC] reg.h:2119
AR_PHY_AGC_CONTROL_ENABLE_NF = 0x00008000           # [SRC] reg.h:2121
AR_PHY_AGC_CONTROL_FLTR_CAL = 0x00010000            # [SRC] reg.h:2122
AR_PHY_AGC_CONTROL_NO_UPDATE_NF = 0x00020000        # [SRC] reg.h:2123
AR_PHY_ADC_CTL = 0x982C                 # [SRC] ar9002_phy.h:66
AR_PHY_ADC_CTL_OFF_PWDADC = 0x00008000  # [SRC] ar9002_phy.h:71
AR_PHY_CL_CAL_CTL = 0xA358              # [SRC] ar9002_phy.h:556
AR_PHY_CL_CAL_ENABLE = 0x00000002       # [SRC] ar9002_phy.h:557
AR_PHY_PARALLEL_CAL_ENABLE = 0x00000001            # [SRC] ar9002_phy.h:558
AR_PHY_FC_DYN2040_EN = 0x00000004       # [SRC] ar9002_phy.h:26 (AR_PHY_TURBO bit)
AR_PHY_TPCRG1_PD_CAL_ENABLE = 0x00400000           # [SRC] ar9002_phy.h:475
AR_PHY_TIMING_CTRL4_IQCAL_LOG_COUNT_MAX = 0x0000F000   # [SRC] ar9002_phy.h:196
AR_PHY_TIMING_CTRL4_DO_CAL = 0x00010000            # [SRC] ar9002_phy.h:198
AR_PHY_CALMODE = 0x99F0                 # [SRC] ar9002_phy.h:378
AR_PHY_CALMODE_IQ = 0x00000000          # [SRC] ar9002_phy.h:380
PER_MAX_LOG_COUNT = 10                  # iq_cal_single_sample.calCountMax [SRC] calib.h:80
# NF nominal (cold, no caldata): 2GHz default noise floor [SRC] ar9002_phy.h:612
AR_PHY_CCA_NOM_VAL_9271_2GHZ = -118
NUM_NF_READINGS = 6                     # [SRC] calib.h:27
AR5416_MAX_CHAINS = 3                   # [SRC] eeprom.h:163
# analog-shift (0x78xx) registers used by ar9271_hw_pa_cal [SRC] reg.h:1469-1581
AR9285_AN_RF2G1 = 0x7820
AR9285_AN_RF2G1_ENPACAL = 0x00000800
AR9285_AN_RF2G1_PDPADRV1 = 0x02000000
AR9285_AN_RF2G2 = 0x7824
AR9285_AN_RF2G2_OFFCAL = 0x00001000
AR9285_AN_RF2G6 = 0x7834
AR9271_AN_RF2G6_OFFS = 0x07F00000
AR9285_AN_RF2G7 = 0x7838
AR9285_AN_RF2G7_PWDDB = 0x00000002
AR9285_AN_RF2G8 = 0x783C
AR9285_AN_RF2G9 = 0x7840
AR9285_AN_RXTXBB1 = 0x7854
AR9285_AN_RXTXBB1_PDRXTXBB1 = 0x00000020
AR9285_AN_RXTXBB1_PDV2I = 0x00000080
AR9285_AN_RXTXBB1_PDDACIF = 0x00000100
AR9285_AN_RXTXBB1_SPARE9 = 0x00000001
AR9285_AN_TOP2 = 0x7868
AR9285_AN_TOP3 = 0x786C
AR9285_AN_TOP3_PWDDAC = 0x00800000

# ---- reset_opmode / operating mode [SRC] hw.c + common(ath)/hw.c + reg.h -----
AR_CFG = 0x0014                         # [SRC] reg.h:29
AR_CFG_SWTD = 0x00000001                # [SRC] reg.h:30
AR_CFG_SWTB = 0x00000002
AR_CFG_SWRD = 0x00000004
AR_CFG_SWRB = 0x00000008
AR_CFG_AP_ADHOC_INDICATION = 0x00000020
AR_CFG_SCLK_32KHZ = 0x00000003          # [SRC] reg.h:664
AR_DIRECT_CONNECT = 0x83A0              # [SRC] reg.h:2063 (tsf2 gen-timer, unused here)
AR_DC_AP_STA_EN = 0x00000001
AR_RESET_TSF = 0x8020                   # [SRC] reg.h:1668
AR_RESET_TSF2_ONCE = 0x02000000
AR_ISR = 0x0080                         # [SRC] reg.h:179
AR_STA_ID1_SADH_MASK = 0x0000FFFF
AR_STA_ID1_STA_AP = 0x00010000
AR_STA_ID1_ADHOC = 0x00020000
AR_STA_ID1_RTS_USE_DEF = 0x00800000
AR_STA_ID1_CRPT_MIC_ENABLE = 0x08000000
AR_STA_ID1_KSRCH_MODE = 0x10000000
AR_STA_ID1_MCAST_KSRCH = 0x80000000
AR_STA_ID1_DEFAULTS = AR_STA_ID1_CRPT_MIC_ENABLE | AR_STA_ID1_MCAST_KSRCH   # [SRC] hw.c:465
AR_BSS_ID0 = 0x8008                     # [SRC] reg.h:1637
AR_BSS_ID1 = 0x800C
AR_BSS_ID1_AID_S = 16
AR_RSSI_THR = 0x8018                    # [SRC] reg.h:1652
INIT_RSSI_THR = 0x00000700              # [SRC] hw.h:192
AR_BSSMSKL = 0x80E0                     # [SRC] reg.h
AR_BSSMSKU = 0x80E4
IFTYPE_STATION = 2                      # NL80211_IFTYPE_STATION
IFTYPE_MONITOR = 6                      # NL80211_IFTYPE_MONITOR

# ---- rf_set_freq (synthesizer) [SRC] ar9002_phy.c:66 + phy.h:20-22 ----------
AR_PHY_SYNTH_CONTROL = 0x9874           # [SRC] ar9002_phy.h:158
AR_PHY_CCK_TX_CTRL = 0xA204             # [SRC] ar9002_phy.h:413
AR_PHY_CCK_TX_CTRL_JAPAN = 0x00000010
# fast channel change — baseband rfbus handshake [SRC] ar9002_phy.h:271,393
AR_PHY_RFBUS_REQ = 0x997C
AR_PHY_RFBUS_REQ_EN = 0x00000001
AR_PHY_RFBUS_GRANT = 0x9C20
AR_PHY_RFBUS_GRANT_EN = 0x00000001
# ar9002 load_ani_reg CCK weak-signal merge [SRC] ar9002_phy.h:418-419
AR_PHY_CCK_DETECT = 0xA208
AR_PHY_CCK_DETECT_WEAK_SIG_THR_CCK = 0x0000003F
CHANSEL_DIV = 15                        # [SRC] phy.h:20
def CHANSEL_2G(freq: int) -> int:       # [SRC] phy.h:21
    return (freq * 0x10000) // CHANSEL_DIV

# ---- TX queues (QCU/DCU) [SRC] mac.c + reg.h:380-602 -----------------------
AR_NUM_DCU = 10                         # [SRC] reg.h:492
ATH9K_NUM_TX_QUEUES = 10
AR_D0_QCUMASK = 0x1000                  # [SRC] reg.h:504
AR_Q0_TXDP = 0x0800
AR_Q0_RDYTIMECFG = 0x0900
AR_Q0_CBRCFG = 0x08C0
AR_Q0_MISC = 0x09C0
AR_D0_LCL_IFS = 0x1040
AR_D0_RETRY_LIMIT = 0x1080
AR_D0_CHNTIME = 0x10C0
AR_D0_MISC = 0x1100
def AR_DQCUMASK(i: int) -> int: return AR_D0_QCUMASK + (i << 2)
def AR_QTXDP(i: int) -> int: return AR_Q0_TXDP + (i << 2)
def AR_QRDYTIMECFG(i: int) -> int: return AR_Q0_RDYTIMECFG + (i << 2)
def AR_QCBRCFG(i: int) -> int: return AR_Q0_CBRCFG + (i << 2)
def AR_QMISC(i: int) -> int: return AR_Q0_MISC + (i << 2)
def AR_DLCL_IFS(i: int) -> int: return AR_D0_LCL_IFS + (i << 2)
def AR_DRETRY_LIMIT(i: int) -> int: return AR_D0_RETRY_LIMIT + (i << 2)
def AR_DCHNTIME(i: int) -> int: return AR_D0_CHNTIME + (i << 2)
def AR_DMISC(i: int) -> int: return AR_D0_MISC + (i << 2)
AR_D_LCL_IFS_CWMIN = 0x000003FF
AR_D_LCL_IFS_CWMAX = 0x000FFC00
AR_D_LCL_IFS_AIFS = 0x0FF00000
AR_D_RETRY_LIMIT_FR_SH = 0x0000000F
AR_D_RETRY_LIMIT_STA_SH = 0x00003F00
AR_D_RETRY_LIMIT_STA_LG = 0x000FC000
AR_Q_MISC_DCU_EARLY_TERM_REQ = 0x00000800
AR_Q_MISC_FSP_DBA_GATED = 0x00000002
AR_Q_MISC_CBR_INCR_DIS1 = 0x00000020
AR_Q_MISC_CBR_INCR_DIS0 = 0x00000040
AR_Q_MISC_BEACON_USE = 0x00000080
AR_Q_RDYTIMECFG_DURATION = 0x00FFFFFF
AR_Q_RDYTIMECFG_EN = 0x01000000
AR_D_MISC_FRAG_WAIT_EN = 0x00000100
AR_D_MISC_CW_BKOFF_EN = 0x00001000
AR_D_MISC_BEACON_USE = 0x00010000
AR_D_MISC_ARB_LOCKOUT_CNTRL_S = 17
AR_D_MISC_ARB_LOCKOUT_CNTRL_GLOBAL = 2
AR_D_MISC_POST_FR_BKOFF_DIS = 0x00200000
AR_D_CHNTIME_DUR = 0x000FFFFF
AR_D_CHNTIME_EN = 0x00100000
AR_IMR_S0 = 0x00A4
AR_IMR_S1 = 0x00A8
AR_IMR_S2 = 0x00AC
AR_IMR_S0_QCU_TXOK = 0x000003FF
AR_IMR_S0_QCU_TXDESC = 0x03FF0000
AR_IMR_S1_QCU_TXERR = 0x000003FF
AR_IMR_S1_QCU_TXEOL = 0x03FF0000
AR_IMR_S2_QCU_TXURN = 0x000003FF
# queue model [SRC] mac.h:583-608,62-69
TXQ_INACTIVE = 0
TXQ_DATA = 1
TXQ_BEACON = 2
TXQ_CAB = 3
TXQ_USEDEFAULT = 0xFFFFFFFF             # (u32)-1
TXQ_FLAG_TXINT_ENABLE = 0x0001
TXQ_FLAG_TXDESCINT_ENABLE = 0x0002
TXQ_FLAG_TXEOLINT_ENABLE = 0x0004
TXQ_FLAG_TXURNINT_ENABLE = 0x0008
INIT_AIFS = 2
INIT_CWMIN = 15
INIT_CWMAX = 1023
INIT_SH_RETRY = 10
INIT_LG_RETRY = 10
INIT_SSH_RETRY = 32
INIT_SLG_RETRY = 32

# ---- interrupt masks / qos / ani cache [SRC] hw.c + ar5008_phy.c + reg.h -----
AR_IMR = 0x00A0                         # [SRC] reg.h:266
AR_IMR_RXOK = 0x00000001
AR_IMR_RXERR = 0x00000004
AR_IMR_RXORN = 0x00000020
AR_IMR_TXOK = 0x00000040
AR_IMR_TXERR = 0x00000100
AR_IMR_TXURN = 0x00000800
AR_IMR_BCNMISC = 0x00800000
AR_IMR_RXMINTR = 0x01000000
AR_IMR_RXINTM = 0x80000000
AR_IMR_TXINTM = 0x40000000
AR_IMR_TXMINTR = 0x00080000
AR_IMR_S2_GTT = 0x00800000
AR_INTR_SYNC_MASK = 0x4034              # non-9340 [SRC] reg.h:1093
AR_INTR_SYNC_DEFAULT = 0x00023F60       # [SRC] reg.h:1071 (resolved OR of the SYNC bits)
AR_MIC_QOS_CONTROL = 0x8118             # [SRC] reg.h:1826
AR_MIC_QOS_SELECT = 0x811C
AR_QOS_NO_ACK = 0x8108                  # [SRC] reg.h:1808
AR_QOS_NO_ACK_TWO_BIT = 0x0000000F
AR_QOS_NO_ACK_BIT_OFF = 0x00000070
AR_QOS_NO_ACK_BYTE_OFF = 0x00000180
AR_TXOP_X = 0x81EC                      # [SRC] reg.h:1955
AR_TXOP_X_VAL = 0x000000FF
AR_TXOP_0_3 = 0x81F0
AR_TXOP_4_7 = 0x81F4
AR_TXOP_8_11 = 0x81F8
AR_TXOP_12_15 = 0x81FC
AR_PHY_SFCORR = 0x9868                  # [SRC] ar9002_phy.h:148
AR_PHY_SFCORR_LOW = 0x986C
AR_PHY_SFCORR_EXT = 0x99C0
AR_PHY_FIND_SIG = 0x9858
AR_PHY_FIND_SIG_LOW = 0x9840
AR_PHY_TIMING5 = 0x9924
AR_PHY_EXT_CCA = 0x99BC

# ---- init_global_settings (MAC timing) [SRC] hw.c:1051 + reg.h --------------
ATH9K_CLOCK_RATE_2GHZ_OFDM = 44         # [SRC] hw.h:1227
AR_PCU_MISC = 0x8120                    # [SRC] reg.h:1829
AR_PCU_MIC_NEW_LOC_ENA = 0x00000004
AR_D_GBL_IFS_SIFS = 0x1030              # [SRC] reg.h:609
AR_D_GBL_IFS_SLOT = 0x1070
AR_D_GBL_IFS_EIFS = 0x10B0
AR_TIME_OUT = 0x8014                    # [SRC] reg.h:1646
AR_TIME_OUT_ACK = 0x00003FFF
AR_TIME_OUT_CTS = 0x3FFF0000
AR_USEC = 0x801C                        # [SRC] reg.h:1660
AR_USEC_USEC = 0x0000007F
AR_USEC_TX_LAT = 0x007FC000
AR_USEC_RX_LAT = 0x1F800000

# ---- set_dma / OBS / RX-interrupt-mitigation [SRC] hw.c:1193 + reg.h ---------
AR_STA_ID1_PRESERVE_SEQNUM = 0x20000000   # [SRC] reg.h:1633
AR_AHB_MODE = 0x4024                    # [SRC] reg.h:1020
AR_AHB_PREFETCH_RD_EN = 0x00000004
AR_TXCFG = 0x0030                       # [SRC] reg.h:79
AR_TXCFG_DMASZ_MASK = 0x00000007
AR_TXCFG_DMASZ_128B = 5
AR_FTRIG = 0x000003F0
AR_FTRIG_S = 4
AR_FTRIG_256B = 0x00000040
AR_RXCFG = 0x0034                       # [SRC] reg.h:99
AR_RXCFG_DMASZ_MASK = 0x00000007
AR_RXCFG_DMASZ_128B = 5
AR_RXFIFO_CFG = 0x8114                  # [SRC] reg.h:1823
AR_OBS = 0x4080                         # non-9300/9340 [SRC] reg.h:1259
AR_OBS_BUS_1 = 0x806c                   # [SRC] reg.h:1745 (check_alive poll, pre-9285 only)
AR_RIMT = 0x002C                        # [SRC] reg.h:64
AR_RIMT_LAST = 0x0000FFFF
AR_RIMT_FIRST = 0xFFFF0000
